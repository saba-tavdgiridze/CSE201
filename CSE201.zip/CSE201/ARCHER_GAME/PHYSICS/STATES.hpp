#ifndef STATES_HPP_INCLUDED
#define STATES_HPP_INCLUDED

namespace STATES{
    enum STATES_ENUM{
        GAME,
        SETTINGS,
        DEAD
    };
}

#endif // STATES_HPP_INCLUDED
